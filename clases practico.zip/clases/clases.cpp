#include <iostream>
#include<string>
#include "Usuario.h"
using namespace std;
int main()
{
    string usuario, password;
    Usuario usuario1("ronald", "mipassword");
    cout << "ingresar usuario: ";
    cin >> usuario;
    cout << "ingresar password: ";
    cin >> password;
    if (usuario1.Verificarlogin(usuario, password))
        cout << "puedes pasar:" << endl;
    else
        cout << "no se puede entrar";

    return 0;
}

